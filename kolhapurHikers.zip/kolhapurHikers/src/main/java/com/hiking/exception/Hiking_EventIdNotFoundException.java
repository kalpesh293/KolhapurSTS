package com.hiking.exception;

public class Hiking_EventIdNotFoundException extends RuntimeException
{


	public Hiking_EventIdNotFoundException(String message)
	{
		super(message);
	}
}