package com.hiking.exception;

public class AdminIdNotFoundException extends RuntimeException{
	

	public AdminIdNotFoundException(String message)
	{
		super(message);
	}

}
