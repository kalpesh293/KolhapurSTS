package com.hiking.exception;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

@ControllerAdvice
public class GlobleException 
{
	@ExceptionHandler(UserIdNotFoundException.class)
	public ResponseEntity<?> resourceNotFoundHandling(UserIdNotFoundException exception,
			WebRequest request){
		UserIdNotFoundException errorDetails = 
				new UserIdNotFoundException(exception.getMessage());
		return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(Hiking_EventIdNotFoundException.class)
	public ResponseEntity<?> resourceNotFoundHandling(Hiking_EventIdNotFoundException exception,
			WebRequest request){
		UserIdNotFoundException errorDetails = 
				new UserIdNotFoundException(exception.getMessage());
		return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(BookingIdNotFoundException.class)
	public ResponseEntity<?> resourceNotFoundHandling(BookingIdNotFoundException exception,
			WebRequest request){
		UserIdNotFoundException errorDetails = 
				new UserIdNotFoundException(exception.getMessage());
		return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
	}
	
	
	@ExceptionHandler(ReviewIdNotFoundException.class)
	public ResponseEntity<?> resourceNotFoundHandling(ReviewIdNotFoundException exception,
			WebRequest request){
		UserIdNotFoundException errorDetails = 
				new UserIdNotFoundException(exception.getMessage());
		return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(PaymentIdNotFoundException.class)
	public ResponseEntity<?> resourceNotFoundHandling(PaymentIdNotFoundException exception,
			WebRequest request){
		UserIdNotFoundException errorDetails = 
				new UserIdNotFoundException(exception.getMessage());
		return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
	}
	
	
	
	

	
	
	

}
