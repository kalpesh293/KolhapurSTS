package com.hiking.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hiking.entity.Admin;
import com.hiking.exception.AdminIdNotFoundException;
import com.hiking.repository.AdminRepository;
import com.hiking.service.AdminService;


@Service
public class AdminServiceImplements implements AdminService{
	
	@Autowired
	AdminRepository adminRepo;

	@Override
	public Admin addAdmin(Admin admin) {
		return adminRepo.save(admin);


	}

	@Override
	public Admin getAdminDetails(int adminId) {
		
		return adminRepo.findById(adminId).orElseThrow(()->new AdminIdNotFoundException("admin id is not correct"));
	}

	@Override
	public Admin updateAdminDetails(Admin admin, Integer adminId) {
		
		Admin UpdateAdmin=adminRepo.findById(adminId).orElseThrow(()->new AdminIdNotFoundException("admin id is not correct"));
		UpdateAdmin.setFirstName(admin.getFirstName());
		UpdateAdmin.setLastName(admin.getLastName());
		UpdateAdmin.setEmail(admin.getEmail());
		UpdateAdmin.setPhone(admin.getPhone());
		UpdateAdmin.setPassword(admin.getPassword());
		return adminRepo.save(UpdateAdmin);
	}

	@Override
	public void deleteAdminDetails(int adminId) {
		
		Admin deleteAdmin=adminRepo.findById(adminId).orElseThrow(()->new AdminIdNotFoundException("admin id is not correct"));
		adminRepo.delete(deleteAdmin);
		
	}

}
