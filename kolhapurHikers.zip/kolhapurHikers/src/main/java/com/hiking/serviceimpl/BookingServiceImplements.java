package com.hiking.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hiking.entity.Booking;
import com.hiking.exception.BookingIdNotFoundException;
import com.hiking.exception.UserIdNotFoundException;
import com.hiking.repository.BookingRepository;
import com.hiking.service.BookingService;

@Service
public class BookingServiceImplements implements BookingService {
	
	@Autowired
	BookingRepository bookRepo;

	@Override
	public Booking addBooking(Booking booking) {
		
		return bookRepo.save(booking);
	}

	@Override
	public Booking getBookingDetails(int bookingId) {
		
		return bookRepo.findById(bookingId).orElseThrow(()->new BookingIdNotFoundException("booking id is not correct"));
	}

	@Override
	public Booking updateBookingDetails(Booking booking, Integer bookingId) {
		
		Booking UpdateBooking=bookRepo.findById(bookingId).orElseThrow(()->new BookingIdNotFoundException("booking id is not correct"));
		UpdateBooking.setUserId(booking.getUserId());
		UpdateBooking.setEventId(booking.getEventId());
		UpdateBooking.setBookingDate(booking.getBookingDate());
		UpdateBooking.setStatus(booking.getStatus());
		return bookRepo.save(UpdateBooking);
	}

	@Override
	public void deleteBookingDetails(int bookingId) {


		Booking deleteBooking=bookRepo.findById(bookingId).orElseThrow(()->new UserIdNotFoundException("user id is not correct"));
		bookRepo.delete(deleteBooking);
		
	}

}
