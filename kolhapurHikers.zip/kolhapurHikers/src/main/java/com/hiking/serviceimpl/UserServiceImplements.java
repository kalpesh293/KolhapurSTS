package com.hiking.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hiking.entity.User;
import com.hiking.exception.UserIdNotFoundException;
import com.hiking.repository.UserRepository;
import com.hiking.service.UserService;

@Service
public class UserServiceImplements implements UserService{

	@Autowired
	UserRepository userRepo;
	@Override
	public User addUser(User user) {
		// TODO Auto-generated method stub
		return userRepo.save(user);
	}

	@Override
	public User getUserDetails(int userId) {
		
		return userRepo.findById(userId).orElseThrow(()->new UserIdNotFoundException("user id is not correct"));
	}

	@Override
	public User updateUserDetails(User user, Integer userId) {
		
		User UpdateUser=userRepo.findById(userId).orElseThrow(()->new UserIdNotFoundException("user id is not correct"));
		UpdateUser.setFirstName(user.getFirstName());
		UpdateUser.setLastName(user.getLastName());
		UpdateUser.setEmail(user.getEmail());
		UpdateUser.setCity(user.getCity());
		UpdateUser.setPhone(user.getPhone());
		UpdateUser.setPassword(user.getPassword());
		return userRepo.save(UpdateUser);
	}

	@Override
	public void deleteUserDetails(int userId) {

		User deleteUser=userRepo.findById(userId).orElseThrow(()->new UserIdNotFoundException("user id is not correct"));
		userRepo.delete(deleteUser);
		
	}
	
	

}
