package com.hiking.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hiking.entity.Hiking_Event;
import com.hiking.exception.Hiking_EventIdNotFoundException;
import com.hiking.repository.Hiking_EventRepository;
import com.hiking.service.Hiking_EventService;

@Service
public class Hiking_EventServiceImplements implements Hiking_EventService 
{
	@Autowired
	Hiking_EventRepository hiking_eventRepo;

	@Override
	public Hiking_Event addHiking_Event(Hiking_Event hiking_event) {
		
		return hiking_eventRepo.save(hiking_event);
	}

	@Override
	public Hiking_Event getHiking_EventDetails(int eventId) {
		
		return hiking_eventRepo.findById(eventId).orElseThrow(()->new Hiking_EventIdNotFoundException("event id is not correct"));
	}

	@Override
	public Hiking_Event updateHiking_EventDetails(Hiking_Event hiking_event, Integer eventId) {
		
		Hiking_Event UpdateHiking_Event=hiking_eventRepo.findById(eventId).orElseThrow(()->new Hiking_EventIdNotFoundException("user id is not correct"));
		UpdateHiking_Event.setEventName(hiking_event.getEventName());
		UpdateHiking_Event.setDiscription(hiking_event.getDiscription());
		UpdateHiking_Event.setLocation(hiking_event.getLocation());
		UpdateHiking_Event.setDeficultyLevel(hiking_event.getDeficultyLevel());
		UpdateHiking_Event.setStartDate(hiking_event.getStartDate());
		UpdateHiking_Event.setEndDate(hiking_event.getEndDate());
		UpdateHiking_Event.setMaxParticipants(hiking_event.getMaxParticipants());
		UpdateHiking_Event.setPrice(hiking_event.getPrice());
		return hiking_eventRepo.save(UpdateHiking_Event);
	}

	@Override
	public void deleteHiking_EventDetails(int eventId) {


		Hiking_Event deleteHiking_Event=hiking_eventRepo.findById(eventId).orElseThrow(()->new Hiking_EventIdNotFoundException("user id is not correct"));
		hiking_eventRepo.delete(deleteHiking_Event);
		
	}

}
