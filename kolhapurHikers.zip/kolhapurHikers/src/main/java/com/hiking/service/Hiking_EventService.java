package com.hiking.service;

import com.hiking.entity.Hiking_Event;

public interface Hiking_EventService {
	
	 Hiking_Event addHiking_Event(Hiking_Event hiking_event);
		
	 Hiking_Event getHiking_EventDetails(int eventId);
		
	 Hiking_Event updateHiking_EventDetails(Hiking_Event hiking_event,Integer eventId);
		
		void deleteHiking_EventDetails(int eventId);

}
