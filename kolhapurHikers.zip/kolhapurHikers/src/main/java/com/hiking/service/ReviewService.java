package com.hiking.service;

import com.hiking.entity.Review;

public interface ReviewService  {
	
	    Review addReview(Review review);
		
		Review getReviewDetails(int reviewId);
		
		Review updateReviewDetails(Review review,Integer reviewId);
		
		void deleteReviewDetails(int reviewId);

}
