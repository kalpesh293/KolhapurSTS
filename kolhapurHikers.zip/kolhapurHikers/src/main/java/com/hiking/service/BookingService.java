package com.hiking.service;

import com.hiking.entity.Booking;

public interface BookingService {

	    Booking addBooking(Booking booking);
		
	    Booking getBookingDetails(int bookingId);
		
	    Booking updateBookingDetails(Booking booking,Integer bookingId);
		
		void deleteBookingDetails(int bookingId);
}
