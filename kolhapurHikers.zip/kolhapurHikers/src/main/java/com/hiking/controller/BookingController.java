package com.hiking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hiking.entity.Booking;
import com.hiking.service.BookingService;

import jakarta.validation.Valid;

@RestController
public class BookingController {
	
	@Autowired
	BookingService bookvice;
	
	@PostMapping("/Booking/addBooking")
	public ResponseEntity<Booking> saveBooking(@Valid @RequestBody Booking booking)
	{
		return new ResponseEntity<Booking>(bookvice.addBooking(booking),HttpStatus.CREATED);
	}
	
	@GetMapping("/Booking/getBooking/{bookingId}")
	public ResponseEntity<Booking> getBooking(@PathVariable("bookingId") int bookingId)
	{
		return new ResponseEntity<Booking>(bookvice.getBookingDetails(bookingId),HttpStatus.OK);
	}
	
	@DeleteMapping("/Booking/removeBooking/{bookingId}")
	public ResponseEntity<String> deleteBooking(@PathVariable("bookingId") int bookingId)
	{
		return new ResponseEntity<String>("Delete successfully...",HttpStatus.OK);
	}
	
	//use put mapping to edit existing data
	@PutMapping("/Booking/updateBooking/{bookingId}")
	public ResponseEntity<Booking> editBooking(@PathVariable("bookingId") Integer bookingId, @Valid @RequestBody Booking booking)
	{
		Booking updateBooking=bookvice.updateBookingDetails(booking , bookingId);
		return new ResponseEntity<Booking>(updateBooking , HttpStatus.OK); 
	}


}
